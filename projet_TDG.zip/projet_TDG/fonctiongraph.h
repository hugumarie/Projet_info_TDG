#ifndef FONCTIONGRAPHIQUE_H_INCLUDED
#define FONCTIONGRAPHIQUE_H_INCLUDED

#include <iostream>

bool printMessageErreur(std::string message);

#endif // FONCTIONGRAPHIQUE_H_INCLUDED
