#include "Sommet.h"

Sommet::Sommet(): m_name("")
{

}

Sommet::Sommet(std::string name): m_name(name)
{

}

Sommet::~Sommet()
{
    //dtor
}
